console.log('Script NUI carregado');

let visible = false;
let updateInterval = null;

document.addEventListener('DOMContentLoaded', function() {
    // Botão de usar posição atual
    document.getElementById('useCurrentPos').addEventListener('click', function() {
        console.log('Botão Usar Posição Atual clicado'); // Debug
        
        fetch(`https://${GetParentResourceName()}/getCurrentPosition`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({})
        })
        .then(resp => {
            console.log('Resposta recebida:', resp); // Debug
            return resp.json();
        })
        .then(data => {
            console.log('Dados recebidos:', data); // Debug
            if (data && data.position) {
                document.getElementById('coordX').value = data.position.x.toFixed(2);
                document.getElementById('coordY').value = data.position.y.toFixed(2);
                document.getElementById('coordZ').value = data.position.z.toFixed(2);
                document.getElementById('heading').value = data.heading.toFixed(2);
            } else {
                console.error('Dados inválidos recebidos:', data);
            }
        })
        .catch(error => {
            console.error('Erro ao obter posição:', error);
        });
    });

    // Botão de limpar coordenadas
    document.getElementById('clearCoords').addEventListener('click', function() {
        console.log('Limpando coordenadas'); // Debug log
        document.getElementById('coordX').value = '';
        document.getElementById('coordY').value = '';
        document.getElementById('coordZ').value = '';
        document.getElementById('heading').value = '';
    });

    // Botão de spawnar prop
    document.getElementById('spawnProp').addEventListener('click', function() {
        const data = {
            propName: document.getElementById('propName').value,
            coords: {
                x: parseFloat(document.getElementById('coordX').value),
                y: parseFloat(document.getElementById('coordY').value),
                z: parseFloat(document.getElementById('coordZ').value)
            },
            heading: parseFloat(document.getElementById('heading').value)
        };

        fetch(`https://${GetParentResourceName()}/spawnProp`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
    });

    // Botão de fechar
    document.getElementById('close').addEventListener('click', function() {
        fetch(`https://${GetParentResourceName()}/closeNUI`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({})
        });
    });

    // Botão de limpar nome da prop
    document.getElementById('clearPropName').addEventListener('click', function() {
        console.log('Limpando nome da prop'); // Debug log
        document.getElementById('propName').value = '';
    });

    // Botão de remover prop próxima
    document.getElementById('removeNearestProp').addEventListener('click', function() {
        fetch(`https://${GetParentResourceName()}/removeNearestProp`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({})
        });
    });
});

// Event listeners do window permanecem fora do DOMContentLoaded
window.addEventListener('message', function(event) {
    console.log('Mensagem recebida:', event.data); // Debug
    if (event.data.type === 'show') {
        document.body.style.display = 'block';
        // Limpa todos os campos quando a NUI é aberta
        clearAllFields();
        visible = true;
    } else if (event.data.type === 'hide') {
        document.body.style.display = 'none';
        visible = false;
    }
});

// Função para limpar todos os campos
function clearAllFields() {
    document.getElementById('propName').value = '';
    document.getElementById('coordX').value = '';
    document.getElementById('coordY').value = '';
    document.getElementById('coordZ').value = '';
    document.getElementById('heading').value = '';
}

document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape' && visible) {
        fetch(`https://${GetParentResourceName()}/closeNUI`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({})
        });
    }
}); 